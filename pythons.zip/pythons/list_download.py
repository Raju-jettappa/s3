import os
import boto3
from botocore.exceptions import ClientError

# ==========================
# AWS CONFIG
# ==========================

AWS_ACCESS_KEY = "AKIA2KPWQGI6MFGWFVU4"
AWS_SECRET_KEY = "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"
AWS_REGION = "ap-south-1"

S3_BUCKET = "test-709723435580-ap-south-1-an"

DOWNLOAD_FOLDER = "downloads"

# ==========================
# CONNECT
# ==========================

s3 = boto3.client(
    "s3",
    aws_access_key_id=AWS_ACCESS_KEY,
    aws_secret_access_key=AWS_SECRET_KEY,
    region_name=AWS_REGION,
)

# ==========================
# LIST FILES
# ==========================

print("\nFiles in Bucket\n")

response = s3.list_objects_v2(Bucket=S3_BUCKET)

files = []

if "Contents" not in response:
    print("Bucket is empty.")
    exit()

for index, obj in enumerate(response["Contents"], start=1):

    files.append(obj["Key"])

    print(
        f"{index}. {obj['Key']}"
        f"\n   Size : {obj['Size']:,} bytes"
        f"\n   Date : {obj['LastModified']}\n"
    )

# ==========================
# SELECT FILE
# ==========================

choice = int(input("Enter file number to download: "))

key = files[choice - 1]

filename = os.path.basename(key)

os.makedirs(DOWNLOAD_FOLDER, exist_ok=True)

destination = os.path.join(DOWNLOAD_FOLDER, filename)

# ==========================
# DOWNLOAD
# ==========================

try:

    print("\nDownloading...")

    s3.download_file(
        S3_BUCKET,
        key,
        destination
    )

    print("\nDownload Complete")
    print(destination)

except ClientError as e:

    error = e.response["Error"]["Code"]

    if error == "InvalidObjectState":

        print("\nThis object is archived in Glacier.")
        print("Restore it first before downloading.")

    else:
        print(e)