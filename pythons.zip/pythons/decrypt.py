from cryptography.fernet import Fernet

# Same key used for encryption
FERNET_KEY = b"gvewiuK5MND-N-5_zogJOy-hS8xik5x55-pDmbEbQMw="

INPUT_FILE = "backup.zip.enc"
OUTPUT_FILE = "backup.zip"

cipher = Fernet(FERNET_KEY)

with open(INPUT_FILE, "rb") as f:
    encrypted_data = f.read()

decrypted_data = cipher.decrypt(encrypted_data)

with open(OUTPUT_FILE, "wb") as f:
    f.write(decrypted_data)

print("Decryption completed.")
print("Output:", OUTPUT_FILE)