import os
import zipfile
import boto3
from cryptography.fernet import Fernet
from datetime import datetime

# ==========================
# CONFIGURATION
# ==========================

SOURCE_FOLDER = "."

ZIP_FILE = "mini_phone_support_system1.zip"
ENCRYPTED_FILE = "backup.zip.enc"

# AWS Configuration
AWS_ACCESS_KEY = "AKIA2KPWQGI6MFGWFVU4"
AWS_SECRET_KEY = "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"
AWS_REGION = "ap-south-1"

S3_BUCKET = "test-709723435580-ap-south-1-an"

# Generate once:
# from cryptography.fernet import Fernet
# print(Fernet.generate_key())

FERNET_KEY = b"gvewiuK5MND-N-5_zogJOy-hS8xik5x55-pDmbEbQMw="

# ==========================
# CREATE ZIP
# ==========================

def create_zip(folder, output_zip):

    print("Creating ZIP...")

    with zipfile.ZipFile(output_zip, "w", zipfile.ZIP_DEFLATED) as zipf:

        for root, dirs, files in os.walk(folder):

            # Skip backup log folder
            if "backup_logs" in root:
                continue

            for file in files:

                # Skip output files
                if file in [
                    ZIP_FILE,
                    ENCRYPTED_FILE,
                    "main.py"
                ]:
                    continue

                path = os.path.join(root, file)

                arc = os.path.relpath(path, folder)

                zipf.write(path, arc)

    print("ZIP Created")


# ==========================
# ENCRYPT FILE
# ==========================

def encrypt_file(input_file, output_file):

    print("Encrypting...")

    cipher = Fernet(FERNET_KEY)

    with open(input_file, "rb") as f:
        data = f.read()

    encrypted = cipher.encrypt(data)

    with open(output_file, "wb") as f:
        f.write(encrypted)

    print("Encryption Completed")


# ==========================
# UPLOAD TO S3
# ==========================

def upload_s3(file_path):

    print("Uploading to S3...")

    s3 = boto3.client(
        "s3",
        aws_access_key_id=AWS_ACCESS_KEY,
        aws_secret_access_key=AWS_SECRET_KEY,
        region_name=AWS_REGION,
    )

    today = datetime.now().strftime("%Y-%m-%d")

    s3_key = f"{today}/{os.path.basename(file_path)}"

    s3.upload_file(
        file_path,
        S3_BUCKET,
        s3_key,
        ExtraArgs={
            "StorageClass": "GLACIER"
        }
    )

    print("Upload Successful")

    # ==========================
    # LOCAL LOG
    # ==========================

    log_folder = "backup_logs"

    os.makedirs(log_folder, exist_ok=True)

    log_file = os.path.join(
        log_folder,
        f"{today}.txt"
    )

    with open(log_file, "a", encoding="utf-8") as log:

        log.write("=" * 80 + "\n")
        log.write(f"Upload Time   : {datetime.now()}\n")
        log.write(f"Bucket        : {S3_BUCKET}\n")
        log.write(f"S3 Folder     : {today}\n")
        log.write(f"S3 File       : {s3_key}\n")
        log.write(f"Local File    : {os.path.abspath(file_path)}\n")
        log.write(f"File Size     : {os.path.getsize(file_path):,} bytes\n")
        log.write("Storage Class : Glacier Flexible Retrieval\n")
        log.write("Status        : SUCCESS\n")
        log.write("=" * 80 + "\n\n")

    print(f"Local log created: {log_file}")


# ==========================
# MAIN
# ==========================

if __name__ == "__main__":

    print("Starting Backup...\n")

    create_zip(SOURCE_FOLDER, ZIP_FILE)

    encrypt_file(ZIP_FILE, ENCRYPTED_FILE)

    upload_s3(ENCRYPTED_FILE)

    print("\nBackup Completed Successfully!")

    print(f"ZIP File       : {ZIP_FILE}")
    print(f"Encrypted File : {ENCRYPTED_FILE}")
    print("Local files were NOT deleted.")